// Audio Service using Web Audio API to avoid external assets
class AudioService {
  private ctx: AudioContext | null = null;

  constructor() {
    // Context is initialized on user interaction
  }

  init() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  // Generate a synthesized sound
  private playTone(freq: number, type: OscillatorType, duration: number, vol: number = 0.1) {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
    
    gain.gain.setValueAtTime(vol, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + duration);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + duration);
  }

  playJump() {
    this.playTone(300, 'triangle', 0.15);
    setTimeout(() => this.playTone(450, 'triangle', 0.1), 100);
  }

  playCorrect() {
    this.playTone(600, 'sine', 0.1);
    setTimeout(() => this.playTone(800, 'sine', 0.2), 100);
    setTimeout(() => this.playTone(1200, 'sine', 0.4), 200);
  }

  playWrong() {
    this.playTone(200, 'sawtooth', 0.3);
    setTimeout(() => this.playTone(150, 'sawtooth', 0.4), 150);
  }

  playBell() {
    // Mimic school bell
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    for(let i=0; i<3; i++) {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.frequency.setValueAtTime(600 + (i*20), now);
        gain.gain.setValueAtTime(0.1, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 1.5);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now + (i * 0.1));
        osc.stop(now + 1.5);
    }
  }

  speak(text: string) {
    if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'vi-VN';
        
        // Attempt to select a Vietnamese voice
        const voices = window.speechSynthesis.getVoices();
        const vnVoice = voices.find(v => v.lang.includes('vi'));
        if (vnVoice) {
            utterance.voice = vnVoice;
        }

        utterance.rate = 0.9;
        window.speechSynthesis.speak(utterance);
    }
  }
}

export const audio = new AudioService();