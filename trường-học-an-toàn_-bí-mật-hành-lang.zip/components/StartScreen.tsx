import React, { useState } from 'react';
import { Difficulty, GameMode } from '../types';
import { audio } from '../services/audio';

interface Props {
  onStart: (diff: Difficulty, mode: GameMode) => void;
  onShowLB: () => void;
}

export const StartScreen: React.FC<Props> = ({ onStart, onShowLB }) => {
  const [diff, setDiff] = useState<Difficulty>('EASY');

  const handleStart = () => {
    audio.init(); // Initialize audio context
    audio.playJump();
    onStart(diff, 'CLASSIC');
  };

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center bg-gradient-to-b from-slate-900 to-slate-800 p-4 text-center overflow-y-auto">
      
      <div className="mb-8 animate-bounce-slight">
          <h1 className="text-5xl md:text-6xl font-black text-blue-400 drop-shadow-white mb-2 tracking-tighter">
            TRƯỜNG HỌC
          </h1>
          <h2 className="text-4xl md:text-5xl font-black text-orange-500 drop-shadow-md tracking-widest">
            BÍ ẨN
          </h2>
      </div>

      <div className="bg-slate-800/90 backdrop-blur-md p-8 rounded-3xl shadow-2xl w-full max-w-md border border-slate-600">
          
          {/* Difficulty Selector */}
          <div className="mb-8">
            <label className="block text-slate-400 font-bold mb-3 uppercase tracking-wider text-sm">Chọn Chế Độ</label>
            <div className="flex gap-2">
                {(['EASY', 'NORMAL', 'HARD'] as Difficulty[]).map(d => (
                    <button
                        key={d}
                        onClick={() => setDiff(d)}
                        className={`flex-1 py-3 rounded-xl font-bold transition-all border-b-4 active:border-b-0 active:translate-y-1 ${
                            diff === d 
                            ? 'bg-blue-600 text-white border-blue-800 shadow-blue-900/50' 
                            : 'bg-slate-700 text-slate-400 border-slate-900 hover:bg-slate-600'
                        }`}
                    >
                        {d === 'EASY' ? 'DỄ' : d === 'NORMAL' ? 'VỪA' : 'KHÓ'}
                    </button>
                ))}
            </div>
            <p className="text-xs text-slate-400 mt-3 h-4 font-mono">
                {diff === 'EASY' ? 'Vượt qua 10 Phòng để thoát.' : diff === 'NORMAL' ? 'Vượt qua 20 Phòng.' : '30 Phòng - Thử thách cực đại!'}
            </p>
          </div>

          <button 
            onClick={handleStart}
            className="w-full bg-orange-600 hover:bg-orange-500 text-white text-xl font-black py-4 rounded-2xl border-b-8 border-orange-800 active:border-b-0 active:translate-y-2 transition-all shadow-xl mb-4 group"
          >
            BẮT ĐẦU KHÁM PHÁ <span className="group-hover:translate-x-1 inline-block transition-transform">▶</span>
          </button>

          <button 
            onClick={onShowLB}
            className="w-full bg-slate-700 hover:bg-slate-600 text-slate-300 font-bold py-3 rounded-xl border border-slate-600"
          >
            🏆 Bảng Xếp Hạng
          </button>
      </div>

      <div className="mt-8 text-slate-500 text-xs font-semibold">
        Bạn phải trả lời đúng câu hỏi để mở khóa cửa phòng tiếp theo.
      </div>

      <style>{`
        .drop-shadow-white { text-shadow: 2px 2px 0 rgba(255,255,255,0.1); }
        @keyframes bounce-slight { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-5px); } }
        .animate-bounce-slight { animation: bounce-slight 3s ease-in-out infinite; }
      `}</style>
    </div>
  );
};