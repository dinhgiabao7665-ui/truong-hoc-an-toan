import React from 'react';
import { PlayerStats } from '../types';

export const HUD: React.FC<{ stats: PlayerStats, level: string }> = ({ stats, level }) => {
  return (
    <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-start z-40 pointer-events-none">
      
      {/* Left: Energy & Social */}
      <div className="flex flex-col gap-2">
        <div className="bg-white/90 backdrop-blur border-2 border-slate-400 rounded-xl p-2 flex items-center gap-3 shadow-lg">
          <div className="w-8 h-8 flex items-center justify-center bg-yellow-100 rounded-full text-xl">⚡</div>
          <div className="flex flex-col">
            <span className="text-xs font-bold text-slate-600 uppercase">Năng lượng</span>
            <div className="w-32 h-3 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className={`h-full transition-all duration-500 ${stats.energy > 50 ? 'bg-green-500' : stats.energy > 20 ? 'bg-yellow-500' : 'bg-red-500'}`}
                style={{ width: `${Math.max(0, Math.min(100, stats.energy))}%` }}
              ></div>
            </div>
          </div>
        </div>

        <div className="bg-white/90 backdrop-blur border-2 border-slate-400 rounded-xl p-2 flex items-center gap-3 shadow-lg">
          <div className="w-8 h-8 flex items-center justify-center bg-blue-100 rounded-full text-xl">🌐</div>
          <div className="flex flex-col">
             <span className="text-xs font-bold text-slate-600 uppercase">Uy tín Mạng</span>
             <div className="flex gap-1">
               {Array.from({length: 10}).map((_, i) => (
                 <div 
                    key={i} 
                    className={`w-2 h-2 rounded-full transition-colors ${i < stats.social ? 'bg-blue-500' : 'bg-gray-300'}`}
                 ></div>
               ))}
             </div>
          </div>
        </div>
      </div>

      {/* Center: Level Info */}
      <div className="bg-slate-800 text-white px-4 py-1 rounded-full text-sm font-bold shadow-lg mt-2">
        CẤP ĐỘ: {level}
      </div>

      {/* Right: Score */}
      <div className="bg-white/90 backdrop-blur border-2 border-yellow-500 rounded-xl p-3 shadow-lg flex flex-col items-center min-w-[100px]">
         <span className="text-xs font-bold text-slate-500 uppercase">Điểm số</span>
         <span className="text-2xl font-black text-yellow-600">{stats.score}</span>
      </div>

    </div>
  );
};
