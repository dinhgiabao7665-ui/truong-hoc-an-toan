import React, { useState, useEffect } from 'react';
import { Question } from '../types';
import { audio } from '../services/audio';

interface QuestionModalProps {
  question: Question;
  timeLimit: number;
  onAnswer: (correct: boolean) => void;
  onClose: () => void;
}

export const QuestionModal: React.FC<QuestionModalProps> = ({ question, timeLimit, onAnswer, onClose }) => {
  const [timeLeft, setTimeLeft] = useState(timeLimit);
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);

  useEffect(() => {
    if (answered) return;
    
    if (timeLeft <= 0) {
      // Time out - auto select wrong or just treat as wrong
      handleSelect(-1); 
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft(prev => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, answered]);

  const handleSelect = (idx: number) => {
    if (answered) return;
    setAnswered(true);
    setSelectedIdx(idx);
    
    const isCorrect = idx === question.c;
    
    if (isCorrect) {
      audio.playCorrect();
    } else {
      audio.playWrong();
    }

    // Delay to let user see the result and lesson
    setTimeout(() => {
      onAnswer(isCorrect);
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur p-4">
      <div className="bg-white w-full max-w-2xl rounded-xl shadow-2xl overflow-hidden border-4 border-slate-700 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-slate-700 p-4 flex justify-between items-center text-white">
             <div className="flex items-center gap-2">
                <span className="text-2xl">❓</span>
                <span className="font-bold uppercase tracking-wider">Câu Hỏi Tình Huống</span>
             </div>
             <div className={`font-mono text-xl font-bold px-3 py-1 rounded ${timeLeft < 10 ? 'bg-red-500 animate-pulse' : 'bg-slate-600'}`}>
                {timeLeft}s
             </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto">
             <h3 className="text-xl md:text-2xl font-bold text-slate-800 mb-6 leading-relaxed">
                {question.q}
             </h3>

             <div className="grid grid-cols-1 gap-3">
                {question.a.map((ans, i) => {
                    let btnClass = "bg-slate-100 border-2 border-slate-300 hover:border-blue-500 hover:bg-blue-50 text-slate-700";
                    
                    if (answered) {
                        if (i === question.c) btnClass = "bg-green-500 border-green-700 text-white font-bold shadow-green-200";
                        else if (i === selectedIdx) btnClass = "bg-red-500 border-red-700 text-white opacity-50";
                        else btnClass = "bg-gray-100 border-gray-200 text-gray-400";
                    }

                    return (
                        <button
                            key={i}
                            onClick={() => handleSelect(i)}
                            disabled={answered}
                            className={`w-full p-4 rounded-lg text-left transition-all ${btnClass} flex items-center gap-3`}
                        >
                            <span className="w-8 h-8 flex items-center justify-center bg-black/10 rounded-full font-bold text-sm shrink-0">
                                {String.fromCharCode(65 + i)}
                            </span>
                            <span className="text-lg">{ans}</span>
                            {answered && i === question.c && <span className="ml-auto text-xl">✅</span>}
                            {answered && i === selectedIdx && i !== question.c && <span className="ml-auto text-xl">❌</span>}
                        </button>
                    )
                })}
             </div>

             {answered && (
                 <div className="mt-6 p-4 bg-yellow-50 border-l-4 border-yellow-500 animate-fade-in">
                     <h4 className="font-bold text-yellow-800 mb-1">BÀI HỌC:</h4>
                     <p className="text-slate-700 italic">{question.lesson}</p>
                 </div>
             )}
        </div>
      </div>
    </div>
  );
};