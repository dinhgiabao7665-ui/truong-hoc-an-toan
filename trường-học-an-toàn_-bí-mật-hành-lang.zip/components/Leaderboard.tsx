import React, { useState, useEffect } from 'react';
import { LeaderboardEntry } from '../types';

interface Props {
  show: boolean;
  onClose: () => void;
  newScore?: number; // If provided, prompts to save
}

export const Leaderboard: React.FC<Props> = ({ show, onClose, newScore }) => {
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [name, setName] = useState('');
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const data = localStorage.getItem('safeSchoolLB');
    if (data) setEntries(JSON.parse(data));
  }, [show]);

  const handleSave = () => {
    if (!name.trim() || newScore === undefined) return;
    const newEntry: LeaderboardEntry = {
        name: name.trim(),
        score: newScore,
        date: new Date().toLocaleDateString('vi-VN')
    };
    const updated = [...entries, newEntry]
        .sort((a, b) => b.score - a.score)
        .slice(0, 10);
    
    localStorage.setItem('safeSchoolLB', JSON.stringify(updated));
    setEntries(updated);
    setSaved(true);
  };

  const clearLB = () => {
      localStorage.removeItem('safeSchoolLB');
      setEntries([]);
  };

  if (!show) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur p-4">
      <div className="bg-white w-full max-w-md rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="bg-yellow-400 p-4 text-center">
            <h2 className="text-2xl font-black text-yellow-900 uppercase">🏆 Bảng Xếp Hạng</h2>
        </div>

        <div className="p-4 flex-1 overflow-y-auto">
            {newScore !== undefined && !saved && (
                <div className="mb-6 bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <p className="font-bold text-blue-800 mb-2">Điểm của bạn: {newScore}</p>
                    <div className="flex gap-2">
                        <input 
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            placeholder="Nhập tên bạn..."
                            className="flex-1 p-2 border rounded"
                            maxLength={15}
                        />
                        <button 
                            onClick={handleSave}
                            disabled={!name}
                            className="bg-blue-500 text-white px-4 rounded font-bold disabled:opacity-50"
                        >
                            LƯU
                        </button>
                    </div>
                </div>
            )}

            {entries.length === 0 ? (
                <p className="text-center text-gray-500 italic">Chưa có ai ghi danh...</p>
            ) : (
                <ul className="space-y-2">
                    {entries.map((e, i) => (
                        <li key={i} className={`flex justify-between p-3 rounded ${i===0 ? 'bg-yellow-100 border-yellow-300 border' : 'bg-gray-50'}`}>
                            <span className="font-bold text-slate-700">
                                #{i+1} {e.name}
                            </span>
                            <span className="font-mono text-slate-500">
                                {e.score}đ <span className="text-xs ml-2 opacity-50">{e.date}</span>
                            </span>
                        </li>
                    ))}
                </ul>
            )}
        </div>

        <div className="p-4 bg-gray-100 flex justify-between">
            <button onClick={clearLB} className="text-xs text-red-500 hover:underline">Xóa dữ liệu</button>
            <button onClick={onClose} className="bg-slate-700 text-white px-6 py-2 rounded-full font-bold">Đóng</button>
        </div>
      </div>
    </div>
  );
};
