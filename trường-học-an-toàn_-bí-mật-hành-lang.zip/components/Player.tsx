import React from 'react';

interface PlayerProps {
  state: 'idle' | 'walking' | 'jump' | 'sad';
  direction: 'left' | 'right';
}

export const Player: React.FC<PlayerProps> = ({ state, direction }) => {
  const isWalking = state === 'walking';
  const isJumping = state === 'jump';
  const isSad = state === 'sad';

  // Animation classes
  const bounceClass = isWalking ? 'animate-bounce-slight' : 'animate-breathe';
  const jumpClass = isJumping ? '-translate-y-12 rotate-3' : '';
  const sadClass = isSad ? 'grayscale-[0.5] contrast-125' : '';
  const dirClass = direction === 'left' ? '-scale-x-100' : '';

  return (
    <div 
      className={`relative w-[60px] h-[130px] transition-transform duration-200 ${jumpClass} ${dirClass}`}
      style={{ zIndex: 50 }}
    >
      {/* BACKPACK (Behind body) - Slimmer & positioned for new body */}
      <div className="absolute top-[50px] left-[2px] w-[24px] h-[40px] bg-slate-700 rounded-lg border-2 border-slate-900 z-0">
          <div className="absolute top-2 left-1 w-[16px] h-[2px] bg-slate-500"></div>
          <div className="absolute bottom-2 left-1 w-[16px] h-[8px] bg-slate-800 rounded"></div>
      </div>

      {/* HEAD - Slimmer */}
      <div className={`absolute left-[8px] top-[10px] w-[44px] h-[44px] bg-[#FFCCBC] rounded-full border-2 border-[#37474F] z-20 ${bounceClass} ${sadClass}`}>
         
         {/* HAIR */}
         <div className="absolute top-[-4px] left-[-4px] right-[-4px] h-[20px] bg-[#1a1a1a] rounded-t-[25px] z-30"></div>
         <div className="absolute top-[8px] left-[-2px] w-[6px] h-[12px] bg-[#1a1a1a] rounded-b-lg z-20"></div>
         <div className="absolute top-[8px] right-[-2px] w-[6px] h-[12px] bg-[#1a1a1a] rounded-b-lg z-20"></div>

         {/* FACE */}
         <div className="absolute inset-0 z-20">
            {/* Eyes */}
            {!isSad ? (
               <>
                 <div className="absolute top-[20px] left-[10px] w-[6px] h-[6px] bg-[#212121] rounded-full">
                    <div className="absolute top-0.5 right-0.5 w-1.5 h-1.5 bg-white rounded-full scale-50"></div>
                 </div>
                 <div className="absolute top-[20px] right-[10px] w-[6px] h-[6px] bg-[#212121] rounded-full">
                    <div className="absolute top-0.5 right-0.5 w-1.5 h-1.5 bg-white rounded-full scale-50"></div>
                 </div>
               </>
            ) : (
                <>
                 <div className="absolute top-[22px] left-[10px] w-[6px] h-[2px] bg-[#212121] rotate-12"></div>
                 <div className="absolute top-[22px] right-[10px] w-[6px] h-[2px] bg-[#212121] -rotate-12"></div>
                </>
            )}

            {/* Mouth */}
            {!isSad ? (
                <div className="absolute bottom-[10px] left-1/2 -translate-x-1/2 w-[10px] h-[3px] bg-pink-300 rounded-full border border-pink-900"></div>
            ) : (
                <div className="absolute bottom-[10px] left-1/2 -translate-x-1/2 w-[10px] h-[3px] bg-transparent border-t-2 border-black rounded-t-full"></div>
            )}
         </div>
      </div>

      {/* SHIRT BODY (White Uniform) - Slimmer */}
      <div className={`absolute top-[52px] left-[11px] w-[38px] h-[45px] bg-white rounded-lg border-2 border-gray-300 z-10 ${sadClass}`}>
         {/* Buttons */}
         <div className="absolute top-[0px] left-1/2 -translate-x-1/2 w-[1px] h-full bg-gray-200"></div>
         <div className="absolute top-[12px] left-1/2 -translate-x-1/2 w-1 h-1 bg-gray-300 rounded-full"></div>
         <div className="absolute top-[26px] left-1/2 -translate-x-1/2 w-1 h-1 bg-gray-300 rounded-full"></div>
         
         {/* RED TIE (Khăn quàng đỏ) - Scaled down */}
         <div className="absolute top-[2px] left-1/2 -translate-x-1/2 w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-t-[10px] border-t-red-600 z-20"></div>
         <div className="absolute top-[8px] left-1/2 -translate-x-1/2 w-[3px] h-[14px] bg-red-600 rotate-12 z-10 rounded-b"></div>
         <div className="absolute top-[8px] left-1/2 -translate-x-[60%] w-[3px] h-[14px] bg-red-700 -rotate-12 z-10 rounded-b"></div>
      </div>

      {/* LEGS / PANTS - Slimmer */}
      <div className="absolute bottom-[10px] left-[15px] w-[30px] h-[32px] bg-[#1a237e] rounded-b-md border-t border-black z-0"></div>
      <div className="absolute bottom-[-5px] left-1/2 -translate-x-1/2 w-[1px] h-[38px] bg-black/20 z-0"></div> 

      {/* SHOES */}
      <div className="absolute bottom-[-5px] left-[15px] w-[14px] h-[10px] bg-black border border-gray-600 rounded">
        <div className="absolute bottom-0 w-full h-[2px] bg-gray-600"></div>
      </div>
      <div className="absolute bottom-[-5px] right-[15px] w-[14px] h-[10px] bg-black border border-gray-600 rounded">
        <div className="absolute bottom-0 w-full h-[2px] bg-gray-600"></div>
      </div>

      {/* ARMS - Slimmer */}
      <div className={`absolute top-[54px] left-[2px] w-[10px] h-[28px] bg-white border border-gray-300 rounded-full origin-top transition-transform ${isWalking ? 'rotate-[25deg]' : (isJumping ? '-rotate-[130deg]' : 'rotate-[10deg]')} ${sadClass}`}>
        <div className="absolute bottom-[-4px] left-1/2 -translate-x-1/2 w-[8px] h-[8px] bg-[#FFCCBC] border border-[#37474F] rounded-full"></div>
      </div>
      <div className={`absolute top-[54px] right-[2px] w-[10px] h-[28px] bg-white border border-gray-300 rounded-full origin-top transition-transform ${isWalking ? '-rotate-[25deg]' : (isJumping ? 'rotate-[130deg]' : '-rotate-[10deg]')} ${sadClass}`}>
        <div className="absolute bottom-[-4px] left-1/2 -translate-x-1/2 w-[8px] h-[8px] bg-[#FFCCBC] border border-[#37474F] rounded-full"></div>
      </div>

      {/* SHADOW */}
      <div className="absolute bottom-[-10px] left-1/2 -translate-x-1/2 w-[30px] h-[6px] bg-black/30 rounded-full blur-[2px]"></div>
      
      <style>{`
        @keyframes breathe { 0%, 100% { transform: scaleY(1); } 50% { transform: scaleY(0.98) translateY(1px); } }
        .animate-breathe { animation: breathe 3s ease-in-out infinite; }
        @keyframes bounce-slight { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-4px); } }
        .animate-bounce-slight { animation: bounce-slight 0.4s ease-in-out infinite; }
      `}</style>
    </div>
  );
};