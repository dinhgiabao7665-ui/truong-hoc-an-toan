import React from 'react';
import { Player } from './Player';
import { NPCManager } from './NPC.tsx';

interface HallwayProps {
  playerIndex: number;
  totalDoors: number;
  playerState: 'idle' | 'walking' | 'jump' | 'sad';
  onDoorClick: (index: number) => void;
  doorStates: boolean[]; // true if solved
  unlockedDoor: number; // visual cue for locked doors
}

export const Hallway: React.FC<HallwayProps> = ({ 
  playerIndex, 
  totalDoors, 
  playerState,
  onDoorClick,
  doorStates,
  unlockedDoor
}) => {
  
  const DOOR_WIDTH = 140;
  const GAP = 120; // Slightly wider for room feel
  const HALL_WIDTH = (totalDoors * (DOOR_WIDTH + GAP)) + 400; 
  
  // Player is at index * (DOOR_WIDTH + GAP) + StartOffset
  const PLAYER_START_X = 200;
  const playerX = PLAYER_START_X + (playerIndex * (DOOR_WIDTH + GAP));
  
  // Camera follow logic
  const containerStyle = {
    transform: `translateX(calc(50vw - ${playerX + (DOOR_WIDTH/2)}px))`,
    width: `${HALL_WIDTH}px`
  };

  return (
    <div className="relative w-full h-full bg-slate-900 overflow-hidden perspective-1000">
      
      {/* DARKER BACKGROUND WALL & DECOR */}
      <div className="absolute top-0 left-0 right-0 h-[70%] bg-[#37474F] border-b-8 border-[#263238] shadow-inner">
        {/* Wall Texture / Pillars to simulate Rooms */}
        <div className="absolute inset-0 opacity-20" 
             style={{ backgroundImage: 'linear-gradient(90deg, transparent 95%, #000 95%)', backgroundSize: `${DOOR_WIDTH + GAP}px 100%`, backgroundPosition: `${PLAYER_START_X - 60}px 0` }}>
        </div>

        {/* Wall Posters */}
        <div className="absolute top-10 left-[10%] p-3 bg-[#eceff1] border-2 border-red-800 shadow-lg rotate-2 w-40 text-center opacity-90">
            <h3 className="text-xs font-bold text-red-900 font-serif uppercase">Cảnh Báo</h3>
            <p className="text-[9px] font-bold text-black">KHÔNG GẶP NGƯỜI LẠ</p>
        </div>
        <div className="absolute top-14 left-[40%] p-3 bg-[#fff9c4] border-2 border-blue-800 shadow-md -rotate-1 w-44 text-center opacity-90">
            <h3 className="text-xs font-bold text-blue-900">MẬT KHẨU MẠNH</h3>
            <p className="text-[9px] text-black">KHÔNG ĐỂ LỘ THÔNG TIN</p>
        </div>
      </div>

      {/* DARKER FLOOR */}
      <div className="absolute bottom-0 left-0 right-0 h-[30%] bg-[#4e342e]">
        {/* Floor Tiles Pattern - Dark Wood/Stone */}
        <div className="w-full h-full opacity-40" 
             style={{ 
               backgroundImage: 'linear-gradient(45deg, #3e2723 25%, transparent 25%, transparent 75%, #3e2723 75%, #3e2723), linear-gradient(45deg, #3e2723 25%, transparent 25%, transparent 75%, #3e2723 75%, #3e2723)',
               backgroundPosition: '0 0, 30px 30px',
               backgroundSize: '60px 60px'
             }}>
        </div>
      </div>

      {/* NPCs Layer */}
      <div className="brightness-75">
        <NPCManager />
      </div>

      {/* WORLD CONTAINER */}
      <div 
        className="absolute inset-0 transition-transform duration-500 ease-out"
        style={containerStyle}
      >
        <div className="relative h-full flex items-end pb-[50px]">
           {Array.from({ length: totalDoors }).map((_, i) => {
             const isLast = i === totalDoors - 1;
             const isPrincipal = isLast; 
             const isSolved = doorStates[i];
             const isLocked = i > unlockedDoor;
             const isNext = i === unlockedDoor && !isSolved;

             return (
               <div 
                key={i} 
                className="absolute flex flex-col items-center"
                style={{ left: `${PLAYER_START_X + (i * (DOOR_WIDTH + GAP))}px`, bottom: '60px' }}
               >
                 {/* PILLAR DIVIDER (Room Separation) */}
                 <div className="absolute -left-[60px] bottom-0 w-8 h-[500px] bg-[#263238] shadow-2xl z-0"></div>

                 {/* CLASSROOM DOOR */}
                 <div 
                   onClick={() => onDoorClick(i)}
                   className={`
                     relative w-[${DOOR_WIDTH}px] h-[240px] 
                     ${isPrincipal ? 'bg-[#3E2723]' : 'bg-[#5D4037]'} 
                     border-x-8 border-t-8 ${isPrincipal ? 'border-[#212121]' : 'border-[#3E2723]'}
                     shadow-[0_0_15px_rgba(0,0,0,0.5)] cursor-pointer
                     flex flex-col items-center justify-start pt-2
                     group transition-all duration-300
                     ${isLocked ? 'brightness-50 grayscale' : 'hover:brightness-110'}
                   `}
                 >
                    {/* Top Window */}
                    <div className="w-[80px] h-[50px] bg-[#CFD8DC] border-4 border-[#3E2723] mb-4 relative overflow-hidden shadow-inner">
                        <div className="absolute inset-0 bg-black/10"></div>
                        {/* Light reflection */}
                        <div className="absolute -top-4 -left-4 w-20 h-20 bg-white/20 rotate-45"></div>
                    </div>

                    {/* Door Label */}
                    <div className={`px-3 py-1 text-xs font-bold mb-8 border border-white/20 rounded shadow-sm
                        ${isPrincipal ? 'bg-red-900 text-white' : 'bg-[#3E2723] text-[#FFECB3]'}
                    `}>
                      {isPrincipal ? 'P. HIỆU TRƯỞNG' : `PHÒNG ${i + 1}`}
                    </div>

                    {/* Handle */}
                    <div className="absolute right-3 top-[55%] w-2 h-10 bg-[#FFD54F] rounded shadow-sm group-hover:bg-[#FFF59D] transition-colors"></div>

                    {/* Status Icons */}
                    {isSolved && !isPrincipal && (
                       <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-green-500 text-white p-2 rounded-full shadow-lg border-2 border-white animate-bounce z-20">
                         ✅
                       </div>
                    )}
                    
                    {isLocked && !isPrincipal && (
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-4xl opacity-50">
                            🔒
                        </div>
                    )}

                    {isNext && !isPrincipal && (
                        <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-orange-500 text-white px-3 py-1 rounded-full shadow-lg border-2 border-white animate-pulse z-20 whitespace-nowrap text-xs font-bold">
                            VÀO ĐÂY ⬇
                        </div>
                    )}
                 </div>
                 
                 {/* Floor Mat / Shadow */}
                 <div className="w-[160px] h-4 bg-black/40 blur-md -mb-2 rounded-[100%]"></div>
               </div>
             )
           })}

           {/* PLAYER */}
           <div 
             className="absolute transition-all duration-300 ease-linear"
             style={{ 
               left: `${PLAYER_START_X + (playerIndex * (DOOR_WIDTH + GAP)) + (DOOR_WIDTH/2) - 30}px`,
               bottom: '50px',
               zIndex: 30
             }}
           >
             <Player state={playerState} direction="right" />
           </div>
        </div>
      </div>
      
      {/* VIGNETTE OVERLAY for darker atmosphere */}
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle,transparent_50%,rgba(0,0,0,0.6)_100%)]"></div>

    </div>
  );
};