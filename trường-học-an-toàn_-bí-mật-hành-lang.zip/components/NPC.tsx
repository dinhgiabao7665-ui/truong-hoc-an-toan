import React, { useEffect, useState } from 'react';

// Simplified character for background
const SimpleChar = ({ color, skin, height }: { color: string, skin: string, height: number }) => (
  <div className="relative flex flex-col items-center" style={{ height: `${height}px`, width: `${height * 0.6}px` }}>
    <div className="w-[70%] h-[30%] rounded-full border border-black/20 z-10" style={{ backgroundColor: skin }}></div>
    <div className="w-[80%] h-[40%] rounded-lg -mt-1 z-0" style={{ backgroundColor: color }}></div>
    <div className="w-[70%] h-[30%] bg-slate-700 -mt-1 rounded-b-lg"></div>
  </div>
);

export const NPCManager: React.FC = () => {
  const [npcs, setNpcs] = useState<Array<{id: number, left: number, speed: number, direction: number, color: string, skin: string, scale: number}>>([]);

  useEffect(() => {
    // Initial spawn
    const initialNpcs = Array.from({ length: 5 }).map((_, i) => createNPC(i));
    setNpcs(initialNpcs);

    const interval = setInterval(() => {
      setNpcs(prev => prev.map(npc => {
        let newLeft = npc.left + (npc.speed * npc.direction);
        
        // Wrap around
        if (newLeft > 110) {
            newLeft = -10;
        } else if (newLeft < -10) {
            newLeft = 110;
        }

        return { ...npc, left: newLeft };
      }));
    }, 50);

    return () => clearInterval(interval);
  }, []);

  const createNPC = (id: number) => {
    const colors = ['#EF5350', '#66BB6A', '#FFA726', '#AB47BC', '#29B6F6'];
    const skins = ['#FFCCBC', '#F5DEB3', '#D7CCC8'];
    const isLeft = Math.random() > 0.5;
    
    return {
      id,
      left: Math.random() * 100,
      speed: 0.1 + Math.random() * 0.2,
      direction: isLeft ? 1 : -1,
      color: colors[Math.floor(Math.random() * colors.length)],
      skin: skins[Math.floor(Math.random() * skins.length)],
      scale: 0.5 + Math.random() * 0.4 // Depth perception
    };
  };

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden" style={{ zIndex: 10 }}>
      {npcs.map(npc => (
        <div 
          key={npc.id}
          className="absolute bottom-[20px] transition-transform"
          style={{ 
            left: `${npc.left}%`, 
            transform: `scale(${npc.scale}) scaleX(${npc.direction === 1 ? -1 : 1})`,
            opacity: npc.scale // Farther away = lighter
          }}
        >
          <SimpleChar color={npc.color} skin={npc.skin} height={100} />
        </div>
      ))}
    </div>
  );
};
