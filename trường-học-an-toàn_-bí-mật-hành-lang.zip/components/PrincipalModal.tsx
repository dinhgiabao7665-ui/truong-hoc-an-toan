import React, { useEffect } from 'react';
import { audio } from '../services/audio';

interface Props {
  onClose: () => void;
}

export const PrincipalModal: React.FC<Props> = ({ onClose }) => {
  const message = "Chào em! Thầy Hiệu Trưởng đây. Hãy nhớ rằng: Không gian mạng là một nơi thú vị để học tập, nhưng cũng đầy rẫy nguy hiểm. Đừng bao giờ chia sẻ thông tin cá nhân, không gặp người lạ và hãy luôn báo cho cha mẹ nếu thấy điều gì bất thường. Chúc em chơi vui và an toàn!";

  useEffect(() => {
    audio.speak(message);
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur p-4">
      <div className="bg-[#FFF8E1] w-full max-w-2xl rounded-lg shadow-2xl border-8 border-[#5D4037] relative overflow-hidden flex flex-col md:flex-row">
        
        {/* Visual */}
        <div className="w-full md:w-1/3 bg-[#5D4037] flex items-center justify-center p-6 relative">
             <div className="w-32 h-32 bg-white rounded-full border-4 border-yellow-500 flex items-center justify-center overflow-hidden">
                {/* CSS Principal Face */}
                <div className="relative w-24 h-24 bg-[#FFCCBC] rounded-full">
                    <div className="absolute top-0 w-full h-8 bg-gray-300"></div> {/* Hair */}
                    <div className="absolute top-8 left-4 w-4 h-4 bg-black rounded-full"></div> {/* Eye */}
                    <div className="absolute top-8 right-4 w-4 h-4 bg-black rounded-full"></div> {/* Eye */}
                    <div className="absolute top-10 left-3 w-18 h-6 border-2 border-black rounded-lg opacity-60"></div> {/* Glasses */}
                    <div className="absolute bottom-6 left-8 w-8 h-2 bg-black opacity-20"></div> {/* Moustache */}
                </div>
             </div>
             <div className="absolute bottom-4 text-white font-bold text-center">THẦY HIỆU TRƯỞNG</div>
        </div>

        {/* Text */}
        <div className="w-full md:w-2/3 p-8 flex flex-col justify-between">
            <div>
                <h2 className="text-3xl font-black text-[#3E2723] mb-4 uppercase">Lời Nhắc Nhở</h2>
                <p className="text-lg text-[#5D4037] leading-relaxed italic font-serif">
                    "{message}"
                </p>
            </div>
            
            <button 
                onClick={onClose}
                className="self-end mt-6 bg-[#4CAF50] hover:bg-[#388E3C] text-white px-8 py-3 rounded-full font-bold shadow-[0_4px_0_rgb(27,94,32)] active:shadow-none active:translate-y-1 transition-all"
            >
                ĐÃ HIỂU, THƯA THẦY!
            </button>
        </div>

      </div>
    </div>
  );
};
